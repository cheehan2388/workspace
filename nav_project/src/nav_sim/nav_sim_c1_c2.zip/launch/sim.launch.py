"""
sim.launch.py — 一個指令開好 Gazebo、橋、TF

用法：
  ros2 launch nav_sim sim.launch.py world:=c1_serpentine.sdf
  ros2 launch nav_sim sim.launch.py world:=c2_sudden.sdf

取代之前要開的三個終端機：gz sim、parameter_bridge、static_transform_publisher。
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory("nav_sim")
    world = LaunchConfiguration("world")

    # 告訴 Gazebo 去哪裡找 model://my_robot 這類模型
    models = os.path.join(pkg, "models")
    resource_path = models + os.pathsep + os.environ.get("GZ_SIM_RESOURCE_PATH", "")

    return LaunchDescription([
        DeclareLaunchArgument("world", default_value="c1_serpentine.sdf",
                              description="worlds/ 資料夾裡的場景檔名"),
        SetEnvironmentVariable("GZ_SIM_RESOURCE_PATH", resource_path),

        # 1. Gazebo（-r：一開就開始跑，不用按 ▶）
        ExecuteProcess(
            cmd=["gz", "sim", "-r", PathJoinSubstitution([pkg, "worlds", world])],
            output="screen",
        ),

        # 2. 橋：跟你之前手打的那串一樣
        Node(
            package="ros_gz_bridge",
            executable="parameter_bridge",
            arguments=[
                "/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan",
                "/odom@nav_msgs/msg/Odometry[gz.msgs.Odometry",
                "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
                "/cmd_vel@geometry_msgs/msg/Twist]gz.msgs.Twist",
                "/tf@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V",
            ],
            parameters=[{"use_sim_time": True}],
            output="screen",
        ),

        # 3. 光達焊在車上的位置：base_link → lidar_link（數字來自 model.sdf 裡光達的 <pose>）
        Node(
            package="tf2_ros",
            executable="static_transform_publisher",
            arguments=["--x", "-0.02", "--y", "0", "--z", "0.11",
                       "--frame-id", "base_link", "--child-frame-id", "lidar_link"],
            parameters=[{"use_sim_time": True}],
        ),
    ])
